# WonderTrader Demos

*如果需要`wtpy`的demo，请到[wtpy的demo](https://github.com/wondertrader/wtpy/tree/master/demos)

+ BackTester        回测器主程序，模块回测的入口程序
+ WtCtaStraFact     CTA策略工厂项目，内置一个DualThrust策略的简单实现
+ WtExeFact         执行单元工厂项目，内置一个简单的执行单元和一个TWAP执行单元
+ WtHftStraFact     高频策略工厂项目，内置一个简单的高频演示策略
+ WtSelStraFact     选股策略工厂项目，内置一个利用DualThrust策略的逻辑实现的日内分钟频次的选股策略
