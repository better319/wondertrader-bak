cmake -DCMAKE_BUILD_TYPE=Debug ./
make
