#include "../WtDtPorter/WtDtPorter.h"

void main()
{
	initialize("dtcfg.json", "logcfg.json");
	start();
}